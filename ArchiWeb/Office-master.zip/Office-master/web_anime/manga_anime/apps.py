from django.apps import AppConfig


class MangaAnimeConfig(AppConfig):
    name = 'manga_anime'

class InscriptionConfig(AppConfig):
    name = 'inscription'
